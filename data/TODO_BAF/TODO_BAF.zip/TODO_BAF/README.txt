Fuente de datos: Banco de Informacion de Telecomunicaciones del Instituto Federal de Telecomunicaciones 

URL: https://bit.ift.org.mx/BitWebApp/

Ruta: Descarga de datos > Descargar todo

Fecha de consulta: mié 30 oct 2019 14∶11∶11 CST
